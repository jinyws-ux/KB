ATC Confluence Publisher Extension

安装：
1. 解压本文件夹
2. 打开 edge://extensions 或 chrome://extensions
3. 开启开发者模式
4. 点击“加载已解压的扩展”
5. 选择 atc_confluence_publisher_extension 文件夹
6. 打开 https://atc.bmw-brilliance.cn/confluence/
7. 点击扩展图标打开右侧面板

使用顺序：
1. 测试登录态
2. 输入 Root Page ID 并保存
3. 加载目录树，选择目标目录
4. 可选：勾选新建目录并输入新目录名
5. 选择 .docx，解析，编辑正文
6. 点击发布到 Confluence

注意：
- 第一版 Word 解析只做精简正文、标题、列表、普通表格提取。
- 页眉页脚、图片、复杂样式暂不作为正文处理。
- 原始 Word 可作为附件上传。
- 插件复用当前浏览器 Confluence 登录态，不保存账号密码。
