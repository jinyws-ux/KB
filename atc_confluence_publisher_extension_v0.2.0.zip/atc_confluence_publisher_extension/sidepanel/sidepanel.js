const BASE_URL = "https://atc.bmw-brilliance.cn/confluence";

const authResultEl = document.getElementById("authResult");
const rootPageIdInput = document.getElementById("rootPageId");
const loadRootBtn = document.getElementById("loadRootBtn");
const saveRootBtn = document.getElementById("saveRootBtn");
const treeStatusEl = document.getElementById("treeStatus");
const pageTreeEl = document.getElementById("pageTree");
const selectedTitleEl = document.getElementById("selectedTitle");
const selectedPageIdEl = document.getElementById("selectedPageId");
const createFolderCheckbox = document.getElementById("createFolderCheckbox");
const folderTitleInput = document.getElementById("folderTitle");
const wordFileInput = document.getElementById("wordFile");
const parseWordBtn = document.getElementById("parseWordBtn");
const parseStatusEl = document.getElementById("parseStatus");
const pageTitleInput = document.getElementById("pageTitle");
const editor = document.getElementById("editor");
const attachOriginalCheckbox = document.getElementById("attachOriginalCheckbox");
const publishBtn = document.getElementById("publishBtn");
const publishResultEl = document.getElementById("publishResult");

let selectedPageId = null;
let selectedTitle = null;
let currentWordFile = null;

init();

async function init() {
  const saved = await chrome.storage.local.get(["rootPageId", "selectedPageId", "selectedTitle"]);
  if (saved.rootPageId) {
    rootPageIdInput.value = saved.rootPageId;
  }
  if (saved.selectedPageId) {
    selectedPageId = saved.selectedPageId;
    selectedTitle = saved.selectedTitle || "";
    selectedTitleEl.textContent = selectedTitle || "已保存选择";
    selectedPageIdEl.textContent = selectedPageId;
  }
}

document.getElementById("testAuthBtn").addEventListener("click", async () => {
  authResultEl.textContent = "测试中...";
  try {
    const data = await confluenceGet("/rest/api/user/current");
    authResultEl.textContent = JSON.stringify(data, null, 2);
  } catch (error) {
    authResultEl.textContent = "请求失败：" + error.message;
  }
});

saveRootBtn.addEventListener("click", async () => {
  const rootPageId = rootPageIdInput.value.trim();
  if (!rootPageId) {
    treeStatusEl.textContent = "Root Page ID 不能为空";
    treeStatusEl.className = "status err";
    return;
  }
  await chrome.storage.local.set({ rootPageId });
  treeStatusEl.textContent = "Root Page ID 已保存";
  treeStatusEl.className = "status ok";
});

loadRootBtn.addEventListener("click", async () => {
  const rootPageId = rootPageIdInput.value.trim();
  if (!rootPageId) {
    setTreeStatus("请先输入 Root Page ID", true);
    return;
  }

  await chrome.storage.local.set({ rootPageId });
  pageTreeEl.innerHTML = "";
  setTreeStatus("正在加载根目录...");

  try {
    const rootPage = await getPageById(rootPageId);
    const rootNode = createTreeNode({
      id: rootPage.id,
      title: rootPage.title
    });
    pageTreeEl.appendChild(rootNode);
    setTreeStatus("目录树加载完成。点击箭头展开，点击标题选择目标目录。");
  } catch (error) {
    setTreeStatus("加载失败：" + error.message, true);
  }
});

parseWordBtn.addEventListener("click", async () => {
  const file = wordFileInput.files[0];
  if (!file) {
    setParseStatus("请先选择 .docx 文件", true);
    return;
  }

  currentWordFile = file;
  if (!pageTitleInput.value.trim()) {
    pageTitleInput.value = file.name.replace(/\.docx$/i, "");
  }

  setParseStatus("正在解析 Word...");
  try {
    const arrayBuffer = await file.arrayBuffer();
    const markdown = await parseDocxToMarkdown(arrayBuffer, file.name);

    editor.value = makeDefaultKnowledgeTemplate({
      title: pageTitleInput.value.trim() || file.name.replace(/\.docx$/i, ""),
      fileName: file.name,
      content: markdown
    });

    setParseStatus("解析完成。请在正文草稿区编辑后发布。");
  } catch (error) {
    setParseStatus("解析失败：" + error.message, true);
  }
});

publishBtn.addEventListener("click", async () => {
  publishResultEl.textContent = "";

  const pageTitle = pageTitleInput.value.trim();
  const rawText = editor.value.trim();

  if (!selectedPageId) {
    publishResultEl.textContent = "请先选择目标目录。";
    return;
  }

  if (!pageTitle) {
    publishResultEl.textContent = "页面标题不能为空。";
    return;
  }

  if (!rawText) {
    publishResultEl.textContent = "页面正文不能为空。";
    return;
  }

  if (createFolderCheckbox.checked && !folderTitleInput.value.trim()) {
    publishResultEl.textContent = "已勾选新建目录，但新目录名为空。";
    return;
  }

  publishResultEl.textContent = "正在发布...";

  try {
    const rootPage = await getPageById(selectedPageId);
    const spaceKey = rootPage.space && rootPage.space.key;
    if (!spaceKey) {
      throw new Error("无法从目标目录获取 space key");
    }

    let finalParentId = selectedPageId;
    let folderPage = null;

    if (createFolderCheckbox.checked) {
      publishResultEl.textContent = "正在创建新目录...";
      folderPage = await createPage({
        title: folderTitleInput.value.trim(),
        spaceKey,
        parentId: selectedPageId,
        storageValue: `<p>该页面由 ATC Confluence Publisher 自动创建，用作目录页。</p>`
      });
      finalParentId = folderPage.id;
    }

    publishResultEl.textContent = "正在创建正文页面...";
    const storageValue = markdownToConfluenceStorage(rawText);
    const createdPage = await createPage({
      title: pageTitle,
      spaceKey,
      parentId: finalParentId,
      storageValue
    });

    if (attachOriginalCheckbox.checked && currentWordFile) {
      publishResultEl.textContent = "页面已创建，正在上传原始 Word 附件...";
      await uploadAttachment(createdPage.id, currentWordFile);
    }

    const pageUrl = buildPageUrl(createdPage);
    publishResultEl.textContent = [
      "发布成功。",
      "",
      `页面标题：${createdPage.title}`,
      `Page ID：${createdPage.id}`,
      pageUrl ? `链接：${pageUrl}` : "链接：未从接口返回，建议用 Page ID 搜索确认。"
    ].join("\n");
  } catch (error) {
    publishResultEl.textContent = "发布失败：" + error.message;
  }
});

function setTreeStatus(text, isError = false) {
  treeStatusEl.textContent = text;
  treeStatusEl.className = isError ? "status err" : "status";
}

function setParseStatus(text, isError = false) {
  parseStatusEl.textContent = text;
  parseStatusEl.className = isError ? "status err" : "status ok";
}

async function confluenceGet(path) {
  const response = await fetch(`${BASE_URL}${path}`, {
    method: "GET",
    credentials: "include",
    headers: {
      "Accept": "application/json"
    }
  });

  const text = await response.text();
  if (!response.ok) {
    throw new Error(`HTTP ${response.status}: ${text.slice(0, 500)}`);
  }
  return text ? JSON.parse(text) : null;
}

async function confluencePost(path, body) {
  const response = await fetch(`${BASE_URL}${path}`, {
    method: "POST",
    credentials: "include",
    headers: {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "X-Atlassian-Token": "nocheck"
    },
    body: JSON.stringify(body)
  });

  const text = await response.text();
  if (!response.ok) {
    throw new Error(`HTTP ${response.status}: ${text.slice(0, 800)}`);
  }
  return text ? JSON.parse(text) : null;
}

async function getPageById(pageId) {
  return await confluenceGet(`/rest/api/content/${encodeURIComponent(pageId)}?expand=space,_links`);
}

async function getChildPages(pageId) {
  const data = await confluenceGet(
    `/rest/api/content/${encodeURIComponent(pageId)}/child/page?limit=100&expand=space,_links`
  );
  return data.results || [];
}

async function createPage({ title, spaceKey, parentId, storageValue }) {
  const body = {
    type: "page",
    title,
    space: {
      key: spaceKey
    },
    ancestors: [
      {
        id: String(parentId)
      }
    ],
    body: {
      storage: {
        value: storageValue,
        representation: "storage"
      }
    }
  };

  return await confluencePost("/rest/api/content", body);
}

async function uploadAttachment(pageId, file) {
  const formData = new FormData();
  formData.append("file", file, file.name);
  formData.append("comment", "Original Word document uploaded by ATC Confluence Publisher");

  const response = await fetch(`${BASE_URL}/rest/api/content/${encodeURIComponent(pageId)}/child/attachment`, {
    method: "POST",
    credentials: "include",
    headers: {
      "X-Atlassian-Token": "nocheck",
      "Accept": "application/json"
    },
    body: formData
  });

  const text = await response.text();
  if (!response.ok) {
    throw new Error(`Attachment upload HTTP ${response.status}: ${text.slice(0, 800)}`);
  }

  return text ? JSON.parse(text) : null;
}

function buildPageUrl(page) {
  if (page && page._links && page._links.webui) {
    return `${BASE_URL}${page._links.webui}`;
  }
  if (page && page.id) {
    return `${BASE_URL}/pages/viewpage.action?pageId=${page.id}`;
  }
  return "";
}

function createTreeNode(page) {
  const wrapper = document.createElement("div");
  wrapper.className = "tree-node";
  wrapper.dataset.pageId = page.id;
  wrapper.dataset.loaded = "false";
  wrapper.dataset.expanded = "false";

  const row = document.createElement("div");
  row.className = "tree-row";

  const expandBtn = document.createElement("button");
  expandBtn.className = "expand-btn";
  expandBtn.textContent = "▶";
  expandBtn.title = "展开/收起";

  const title = document.createElement("span");
  title.className = "page-title";
  title.textContent = page.title;
  title.title = page.title;

  const childrenBox = document.createElement("div");
  childrenBox.className = "children";
  childrenBox.style.display = "none";

  expandBtn.addEventListener("click", async (event) => {
    event.stopPropagation();
    await toggleNode(wrapper, expandBtn, childrenBox, page.id);
  });

  row.addEventListener("click", () => {
    selectNode(row, page.id, page.title);
  });

  row.appendChild(expandBtn);
  row.appendChild(title);
  wrapper.appendChild(row);
  wrapper.appendChild(childrenBox);
  return wrapper;
}

async function toggleNode(wrapper, expandBtn, childrenBox, pageId) {
  const expanded = wrapper.dataset.expanded === "true";
  const loaded = wrapper.dataset.loaded === "true";

  if (expanded) {
    wrapper.dataset.expanded = "false";
    expandBtn.textContent = "▶";
    childrenBox.style.display = "none";
    return;
  }

  wrapper.dataset.expanded = "true";
  expandBtn.textContent = "▼";
  childrenBox.style.display = "block";

  if (!loaded) {
    childrenBox.textContent = "加载中...";
    try {
      const children = await getChildPages(pageId);
      childrenBox.innerHTML = "";

      if (children.length === 0) {
        const empty = document.createElement("div");
        empty.className = "status";
        empty.textContent = "没有子页面";
        childrenBox.appendChild(empty);
      } else {
        for (const child of children) {
          childrenBox.appendChild(createTreeNode({
            id: child.id,
            title: child.title
          }));
        }
      }

      wrapper.dataset.loaded = "true";
    } catch (error) {
      childrenBox.textContent = "加载失败：" + error.message;
    }
  }
}

function selectNode(row, pageId, title) {
  const oldSelected = pageTreeEl.querySelector(".tree-row.selected");
  if (oldSelected) {
    oldSelected.classList.remove("selected");
  }

  row.classList.add("selected");
  selectedPageId = pageId;
  selectedTitle = title;

  selectedTitleEl.textContent = selectedTitle;
  selectedPageIdEl.textContent = selectedPageId;

  chrome.storage.local.set({
    selectedPageId,
    selectedTitle
  });
}

/**
 * Minimal DOCX parser:
 * - Reads ZIP central directory
 * - Decompresses word/document.xml using browser DecompressionStream
 * - Extracts paragraphs and tables
 * This is intentionally simplified for AI-friendly content extraction.
 */
async function parseDocxToMarkdown(arrayBuffer, fileName) {
  const entries = readZipEntries(arrayBuffer);
  const documentEntry = entries["word/document.xml"];
  if (!documentEntry) {
    throw new Error("没有找到 word/document.xml，确认文件是否为 .docx");
  }

  const xmlText = await readZipText(arrayBuffer, documentEntry);
  const xmlDoc = new DOMParser().parseFromString(xmlText, "application/xml");

  const parserError = xmlDoc.querySelector("parsererror");
  if (parserError) {
    throw new Error("Word XML 解析失败");
  }

  const body = findFirstByLocalName(xmlDoc, "body");
  if (!body) {
    throw new Error("没有找到 Word 正文");
  }

  const lines = [];
  for (const child of Array.from(body.children)) {
    if (localName(child) === "p") {
      const paragraph = parseParagraph(child);
      if (!paragraph.text || shouldDropParagraph(paragraph.text)) {
        continue;
      }

      if (paragraph.headingLevel > 0) {
        lines.push("");
        lines.push(`${"#".repeat(paragraph.headingLevel)} ${paragraph.text}`);
        lines.push("");
      } else if (paragraph.isList) {
        lines.push(`- ${paragraph.text}`);
      } else {
        lines.push(paragraph.text);
        lines.push("");
      }
    } else if (localName(child) === "tbl") {
      const tableMd = parseTable(child);
      if (tableMd) {
        lines.push("");
        lines.push(tableMd);
        lines.push("");
      }
    }
  }

  const cleaned = cleanMarkdown(lines.join("\n"));
  if (!cleaned.trim()) {
    throw new Error("没有提取到正文内容，可能是扫描版/图片版 Word，或格式过于特殊。");
  }

  return cleaned;
}

function parseParagraph(p) {
  const textParts = [];

  for (const node of p.getElementsByTagName("*")) {
    const ln = localName(node);
    if (ln === "t") {
      textParts.push(node.textContent || "");
    } else if (ln === "tab") {
      textParts.push("\t");
    } else if (ln === "br") {
      textParts.push("\n");
    }
  }

  const text = textParts.join("").replace(/\s+\n/g, "\n").trim();

  let headingLevel = 0;
  let isList = false;

  const pPr = firstChildByLocalName(p, "pPr");
  if (pPr) {
    const pStyle = firstDescendantByLocalName(pPr, "pStyle");
    const styleVal = pStyle ? getAttrByLocalName(pStyle, "val") : "";

    if (styleVal) {
      const s = styleVal.toLowerCase();
      if (s.includes("heading1") || s.includes("title1") || s === "1") headingLevel = 1;
      else if (s.includes("heading2") || s.includes("title2") || s === "2") headingLevel = 2;
      else if (s.includes("heading3") || s.includes("title3") || s === "3") headingLevel = 3;
      else if (s.includes("heading4") || s.includes("title4") || s === "4") headingLevel = 4;
    }

    if (firstDescendantByLocalName(pPr, "numPr")) {
      isList = true;
    }
  }

  return { text, headingLevel, isList };
}

function parseTable(tbl) {
  const rows = [];
  for (const tr of Array.from(tbl.children).filter(n => localName(n) === "tr")) {
    const cells = [];
    for (const tc of Array.from(tr.children).filter(n => localName(n) === "tc")) {
      const cellTexts = [];
      for (const p of Array.from(tc.getElementsByTagName("*")).filter(n => localName(n) === "p")) {
        const parsed = parseParagraph(p);
        if (parsed.text) {
          cellTexts.push(parsed.text);
        }
      }
      cells.push(cellTexts.join("<br/>").replace(/\|/g, "\\|"));
    }
    if (cells.some(c => c.trim())) {
      rows.push(cells);
    }
  }

  if (rows.length === 0) return "";

  const maxCols = Math.max(...rows.map(r => r.length));
  const normalized = rows.map(r => {
    const copy = r.slice();
    while (copy.length < maxCols) copy.push("");
    return copy;
  });

  const header = normalized[0];
  const md = [];
  md.push("| " + header.join(" | ") + " |");
  md.push("| " + Array(maxCols).fill("---").join(" | ") + " |");

  for (const row of normalized.slice(1)) {
    md.push("| " + row.join(" | ") + " |");
  }

  return md.join("\n");
}

function shouldDropParagraph(text) {
  const t = text.trim();
  if (!t) return true;

  const lowered = t.toLowerCase();
  const dropKeywords = [
    "confidential",
    "revision history",
    "signature",
    "approver",
    "修订记录",
    "审批记录",
    "目录"
  ];

  if (t.length <= 2 && /^[\d.]+$/.test(t)) return true;

  return dropKeywords.some(k => lowered.includes(k.toLowerCase()));
}

function cleanMarkdown(text) {
  const lines = text.split(/\r?\n/).map(line => line.replace(/[ \t]+$/g, ""));
  const result = [];
  let emptyCount = 0;

  for (const line of lines) {
    if (line.trim() === "") {
      emptyCount += 1;
      if (emptyCount <= 1) result.push("");
    } else {
      emptyCount = 0;
      result.push(line);
    }
  }

  return result.join("\n").trim() + "\n";
}

function makeDefaultKnowledgeTemplate({ title, fileName, content }) {
  const now = new Date().toLocaleString();
  return [
    `# ${title}`,
    "",
    "## 1. 文档概览",
    "",
    `- 来源文件：${fileName}`,
    `- 整理时间：${now}`,
    "- 整理方式：ATC Confluence Publisher 自动提取，发布前可人工编辑",
    "",
    "## 2. 核心结论",
    "",
    "- 请在发布前补充该文档最重要的结论。",
    "",
    "## 3. 正文内容",
    "",
    content.trim(),
    "",
    "## 4. 注意事项",
    "",
    "- 请在发布前补充生产环境操作风险、限制条件或审批要求。",
    ""
  ].join("\n");
}

function markdownToConfluenceStorage(markdown) {
  const lines = markdown.replace(/\r\n/g, "\n").split("\n");
  const html = [];
  let inUl = false;
  let inOl = false;
  let inCode = false;
  let codeLang = "";
  let codeLines = [];
  let tableBuffer = [];

  function closeLists() {
    if (inUl) {
      html.push("</ul>");
      inUl = false;
    }
    if (inOl) {
      html.push("</ol>");
      inOl = false;
    }
  }

  function flushCode() {
    if (!inCode) return;
    html.push(`<ac:structured-macro ac:name="code"><ac:parameter ac:name="language">${escapeXml(codeLang || "text")}</ac:parameter><ac:plain-text-body><![CDATA[${codeLines.join("\n")}]]></ac:plain-text-body></ac:structured-macro>`);
    inCode = false;
    codeLang = "";
    codeLines = [];
  }

  function flushTable() {
    if (tableBuffer.length === 0) return;
    closeLists();

    const rows = tableBuffer
      .filter(row => row.trim().startsWith("|"))
      .map(row => row.trim().replace(/^\|/, "").replace(/\|$/, "").split("|").map(c => c.trim()));

    if (rows.length >= 2) {
      html.push("<table><tbody>");
      rows.forEach((row, idx) => {
        if (idx === 1 && row.every(c => /^:?-{3,}:?$/.test(c))) return;
        html.push("<tr>");
        row.forEach(cell => {
          const tag = idx === 0 ? "th" : "td";
          html.push(`<${tag}>${inlineMarkdownToHtml(cell)}</${tag}>`);
        });
        html.push("</tr>");
      });
      html.push("</tbody></table>");
    }
    tableBuffer = [];
  }

  for (const rawLine of lines) {
    const line = rawLine.trimEnd();

    if (line.startsWith("```")) {
      if (inCode) {
        flushCode();
      } else {
        closeLists();
        flushTable();
        inCode = true;
        codeLang = line.slice(3).trim() || "text";
        codeLines = [];
      }
      continue;
    }

    if (inCode) {
      codeLines.push(rawLine);
      continue;
    }

    if (line.trim().startsWith("|")) {
      tableBuffer.push(line);
      continue;
    } else {
      flushTable();
    }

    if (line.trim() === "") {
      closeLists();
      continue;
    }

    const headingMatch = line.match(/^(#{1,6})\s+(.+)$/);
    if (headingMatch) {
      closeLists();
      const level = headingMatch[1].length;
      html.push(`<h${level}>${inlineMarkdownToHtml(headingMatch[2])}</h${level}>`);
      continue;
    }

    const ulMatch = line.match(/^\s*[-*]\s+(.+)$/);
    if (ulMatch) {
      if (inOl) {
        html.push("</ol>");
        inOl = false;
      }
      if (!inUl) {
        html.push("<ul>");
        inUl = true;
      }
      html.push(`<li>${inlineMarkdownToHtml(ulMatch[1])}</li>`);
      continue;
    }

    const olMatch = line.match(/^\s*\d+\.\s+(.+)$/);
    if (olMatch) {
      if (inUl) {
        html.push("</ul>");
        inUl = false;
      }
      if (!inOl) {
        html.push("<ol>");
        inOl = true;
      }
      html.push(`<li>${inlineMarkdownToHtml(olMatch[1])}</li>`);
      continue;
    }

    closeLists();
    html.push(`<p>${inlineMarkdownToHtml(line)}</p>`);
  }

  flushCode();
  flushTable();
  closeLists();

  return html.join("\n");
}

function inlineMarkdownToHtml(text) {
  let s = escapeXml(text);
  s = s.replace(/`([^`]+)`/g, "<code>$1</code>");
  s = s.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
  s = s.replace(/\*([^*]+)\*/g, "<em>$1</em>");
  s = s.replace(/&lt;br\/&gt;/g, "<br/>");
  return s;
}

function escapeXml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function localName(node) {
  return node.localName || node.nodeName.split(":").pop();
}

function findFirstByLocalName(root, name) {
  return Array.from(root.getElementsByTagName("*")).find(n => localName(n) === name);
}

function firstChildByLocalName(node, name) {
  return Array.from(node.children).find(n => localName(n) === name);
}

function firstDescendantByLocalName(node, name) {
  return Array.from(node.getElementsByTagName("*")).find(n => localName(n) === name);
}

function getAttrByLocalName(node, attrName) {
  for (const attr of Array.from(node.attributes || [])) {
    if ((attr.localName || attr.name.split(":").pop()) === attrName) {
      return attr.value;
    }
  }
  return "";
}

function readZipEntries(arrayBuffer) {
  const view = new DataView(arrayBuffer);
  const bytes = new Uint8Array(arrayBuffer);
  const eocdOffset = findEndOfCentralDirectory(bytes);
  if (eocdOffset < 0) {
    throw new Error("不是有效的 zip/docx 文件：找不到中央目录");
  }

  const centralDirSize = view.getUint32(eocdOffset + 12, true);
  const centralDirOffset = view.getUint32(eocdOffset + 16, true);
  const entries = {};

  let offset = centralDirOffset;
  const end = centralDirOffset + centralDirSize;

  while (offset < end) {
    const sig = view.getUint32(offset, true);
    if (sig !== 0x02014b50) {
      break;
    }

    const compressionMethod = view.getUint16(offset + 10, true);
    const compressedSize = view.getUint32(offset + 20, true);
    const uncompressedSize = view.getUint32(offset + 24, true);
    const fileNameLength = view.getUint16(offset + 28, true);
    const extraLength = view.getUint16(offset + 30, true);
    const commentLength = view.getUint16(offset + 32, true);
    const localHeaderOffset = view.getUint32(offset + 42, true);

    const nameBytes = bytes.slice(offset + 46, offset + 46 + fileNameLength);
    const fileName = new TextDecoder("utf-8").decode(nameBytes);

    entries[fileName] = {
      fileName,
      compressionMethod,
      compressedSize,
      uncompressedSize,
      localHeaderOffset
    };

    offset += 46 + fileNameLength + extraLength + commentLength;
  }

  return entries;
}

function findEndOfCentralDirectory(bytes) {
  for (let i = bytes.length - 22; i >= Math.max(0, bytes.length - 65536); i--) {
    if (
      bytes[i] === 0x50 &&
      bytes[i + 1] === 0x4b &&
      bytes[i + 2] === 0x05 &&
      bytes[i + 3] === 0x06
    ) {
      return i;
    }
  }
  return -1;
}

async function readZipText(arrayBuffer, entry) {
  const view = new DataView(arrayBuffer);
  const bytes = new Uint8Array(arrayBuffer);
  const localOffset = entry.localHeaderOffset;

  const sig = view.getUint32(localOffset, true);
  if (sig !== 0x04034b50) {
    throw new Error(`无效的本地文件头：${entry.fileName}`);
  }

  const fileNameLength = view.getUint16(localOffset + 26, true);
  const extraLength = view.getUint16(localOffset + 28, true);
  const dataStart = localOffset + 30 + fileNameLength + extraLength;
  const compressedData = bytes.slice(dataStart, dataStart + entry.compressedSize);

  let data;
  if (entry.compressionMethod === 0) {
    data = compressedData;
  } else if (entry.compressionMethod === 8) {
    data = await inflateRaw(compressedData);
  } else {
    throw new Error(`不支持的 zip 压缩方式：${entry.compressionMethod}`);
  }

  return new TextDecoder("utf-8").decode(data);
}

async function inflateRaw(compressedData) {
  if (typeof DecompressionStream === "undefined") {
    throw new Error("当前浏览器不支持 DecompressionStream，无法解压 docx。建议使用较新的 Chrome/Edge。");
  }

  const stream = new Blob([compressedData]).stream().pipeThrough(new DecompressionStream("deflate-raw"));
  const arrayBuffer = await new Response(stream).arrayBuffer();
  return new Uint8Array(arrayBuffer);
}
