ATC Confluence Publisher Extension v0.3.0

主要变化：
1. 移除主界面的“测试登录态”。
2. Root Page ID 移到右上角设置里。
3. 启动后如果已保存 Root Page ID，会自动加载目录树。
4. 目录选择区不再显示主输入框，只显示当前选择。
5. 页面顶部自动增加发布时间和发布人：
   - 发布时间使用 Confluence storage 的 <time datetime="YYYY-MM-DD" />。
   - 发布人来自 /rest/api/user/current。
6. 保留新建目录功能。
7. 新增批量上传模式：
   - 先选择目标目录，再将文件加入队列。
   - 每个文件会记住加入队列时的目录。
   - 因此可以支持不同文件发布到不同目录。
   - 批量模式不打开编辑器，自动解析并直接发布。
8. 原始 Word 可以作为附件上传。

安装：
1. 解压 zip
2. 打开 edge://extensions 或 chrome://extensions
3. 开启开发者模式
4. 加载已解压的扩展
5. 选择 atc_confluence_publisher_extension_v0.3.0 文件夹
6. 打开 https://atc.bmw-brilliance.cn/confluence/
7. 点击插件图标打开右侧面板

批量上传到不同目录的方法：
1. 选择目录 A
2. 选择一批 Word
3. 点击“加入批量队列”
4. 再选择目录 B
5. 选择另一批 Word
6. 再点击“加入批量队列”
7. 点击“开始批量发布”
