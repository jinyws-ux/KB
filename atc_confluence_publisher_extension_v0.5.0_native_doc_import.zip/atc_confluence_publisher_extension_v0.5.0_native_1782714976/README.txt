ATC Confluence Publisher Extension v0.5.0

本版本只保留一种导入方式：
- Confluence 原生 Doc 文件导入模式

核心流程：
1. 插件在目标目录下创建空白页面。
2. 调用 Confluence 原生 Word 上传接口：
   POST /confluence/pages/worddav/importword.action?pageId=<新页面ID>
   multipart/form-data:
   - atl_token
   - filename = Word 文件
   - submit = 下一步
3. 调用 Confluence 原生导入确认接口：
   POST /confluence/pages/worddav/doimportword.action
   application/x-www-form-urlencoded:
   - atl_token
   - pageId
   - treeDepth
   - advanced=true
   - docTitle
   - importSpace=false
   - conflict=1
   - submit=导入
4. 插件再用 REST API 把发布时间/发布人插到页面最前面。

注意：
- 这是基于已抓到的 Confluence 老式 action 接口实现的，属于内部页面接口自动化，不是官方 REST API。
- 如果导入失败，优先看右侧日志里显示在哪一步失败。
- 默认 treeDepth=0，不按标题拆分。
