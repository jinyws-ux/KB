const BASE_URL="https://atc.bmw-brilliance.cn/confluence";
const $=id=>document.getElementById(id);
let rootPageId="",selectedPageId=null,selectedTitle=null,currentUser=null,batchItems=[],treeDepth="0";
init();

async function init(){
  bind();
  const saved=await chrome.storage.local.get(["rootPageId","selectedPageId","selectedTitle","treeDepth"]);
  rootPageId=saved.rootPageId||"";
  treeDepth=saved.treeDepth||"0";
  $("settingsRootPageId").value=rootPageId;
  $("settingsTreeDepth").value=treeDepth;
  if(rootPageId)$("rootStatusLabel").textContent=`Root：${rootPageId}`;
  if(saved.selectedPageId){selectedPageId=saved.selectedPageId;selectedTitle=saved.selectedTitle||"";refreshSelected();}
  renderBatchList();
  await loadUser();
  if(rootPageId)await loadTree();else setTreeStatus("请先点击右上角设置，配置 Root Page ID。");
}

function bind(){
  $("reloadTreeBtn").onclick=loadTree;
  $("openSettingsBtn").onclick=()=>$("settingsModal").classList.remove("hidden");
  $("closeSettingsBtn").onclick=()=>$("settingsModal").classList.add("hidden");
  $("saveSettingsBtn").onclick=()=>saveSettings(false);
  $("settingsReloadTreeBtn").onclick=()=>saveSettings(true);
  $("openTargetSelectorBtn").onclick=openTargetSelector;
  $("batchChooseTargetBtn").onclick=openTargetSelector;
  $("closeTargetSelectorBtn").onclick=()=>$("targetSelectorModal").classList.add("hidden");
  $("reloadTargetSelectorBtn").onclick=loadTargetSelectorTree;
  $("addBatchBtn").onclick=addBatch;
  $("clearBatchBtn").onclick=()=>{batchItems=[];renderBatchList();$("batchResult").textContent="队列已清空。"};
  $("publishBatchBtn").onclick=publishBatch;
}

async function saveSettings(reload){
  rootPageId=$("settingsRootPageId").value.trim();
  treeDepth=$("settingsTreeDepth").value;
  if(!rootPageId){$("settingsResult").textContent="Root Page ID 不能为空。";return;}
  await chrome.storage.local.set({rootPageId,treeDepth});
  $("rootStatusLabel").textContent=`Root：${rootPageId}`;
  $("settingsResult").textContent="设置已保存。";
  if(reload){$("settingsModal").classList.add("hidden");await loadTree();}
}

async function loadUser(){
  try{currentUser=await getJson("/rest/api/user/current");$("currentUserLabel").textContent=`用户：${userName()}`;}
  catch(e){$("currentUserLabel").textContent="用户：读取失败";}
}

function userName(){return currentUser?.displayName||currentUser?.fullName||currentUser?.username||currentUser?.name||"Unknown";}

async function loadTree(){
  if(!rootPageId){setTreeStatus("请先在设置里配置 Root Page ID。",true);return;}
  $("pageTree").innerHTML="";
  setTreeStatus("正在加载目录树...");
  try{const p=await getPage(rootPageId);$("pageTree").appendChild(treeNode(p,{}));setTreeStatus("目录树已加载。");}
  catch(e){setTreeStatus("加载失败："+e.message,true);}
}

async function openTargetSelector(){
  $("targetSelectorModal").classList.remove("hidden");
  await loadTargetSelectorTree();
}

async function loadTargetSelectorTree(){
  $("targetSelectorTree").innerHTML="";
  if(!rootPageId){$("targetSelectorStatus").textContent="请先配置 Root。";$("targetSelectorStatus").className="status err";return;}
  $("targetSelectorStatus").textContent="正在加载...";
  $("targetSelectorStatus").className="status";
  try{const p=await getPage(rootPageId);$("targetSelectorTree").appendChild(treeNode(p,{modal:true}));$("targetSelectorStatus").textContent="点击目录标题即可选择。";}
  catch(e){$("targetSelectorStatus").textContent="加载失败："+e.message;$("targetSelectorStatus").className="status err";}
}

function treeNode(page,opt={}){
  const w=document.createElement("div");w.className="tree-node";w.dataset.loaded="false";w.dataset.expanded="false";
  const r=document.createElement("div");r.className="tree-row";
  const b=document.createElement("button");b.className="expand-btn";b.textContent="▶";b.type="button";
  const t=document.createElement("span");t.className="page-title";t.textContent=page.title;t.title=page.title;
  const c=document.createElement("div");c.className="children";c.style.display="none";
  b.onclick=async e=>{e.stopPropagation();await toggle(w,b,c,page.id,opt);};
  r.onclick=()=>selectNode(r,page.id,page.title,opt);
  r.append(b,t);w.append(r,c);return w;
}

async function toggle(w,b,c,id,opt){
  const ex=w.dataset.expanded==="true",lo=w.dataset.loaded==="true";
  if(ex){w.dataset.expanded="false";b.textContent="▶";c.style.display="none";return;}
  w.dataset.expanded="true";b.textContent="▼";c.style.display="block";
  if(!lo){
    c.textContent="加载中...";
    try{
      const ch=await getChildren(id);
      c.innerHTML="";
      if(!ch.length)c.textContent="没有子页面";
      else ch.forEach(x=>c.appendChild(treeNode(x,opt)));
      w.dataset.loaded="true";
    }catch(e){c.textContent="加载失败："+e.message;}
  }
}

function selectNode(row,id,title,opt={}){
  document.querySelectorAll(".tree-row.selected").forEach(x=>x.classList.remove("selected"));
  row.classList.add("selected");
  selectedPageId=id;selectedTitle=title;
  refreshSelected();
  chrome.storage.local.set({selectedPageId,selectedTitle});
  if(opt.modal)$("targetSelectorModal").classList.add("hidden");
}

function refreshSelected(){
  $("selectedTitle").textContent=selectedTitle||"已保存选择";
  $("selectedPageId").textContent=selectedPageId||"-";
  $("batchSelectedTitle").textContent=selectedTitle||"未选择";
  $("batchSelectedPageId").textContent=selectedPageId||"-";
}

function addBatch(){
  const files=Array.from($("batchFiles").files||[]);
  if(!selectedPageId){$("batchResult").textContent="请先选择目标目录。";return;}
  if(!files.length){$("batchResult").textContent="请先选择文件。";return;}
  const createFolder=$("batchCreateFolderCheckbox").checked;
  const folderTitle=$("batchFolderTitle").value.trim();
  if(createFolder&&!folderTitle){$("batchResult").textContent="已勾选新建目录，但新目录名为空。";return;}
  let n=0;
  for(const file of files){
    if(!/\.(doc|docx)$/i.test(file.name))continue;
    batchItems.push({
      id:String(Date.now()+Math.random()),
      file,
      pageTitle:file.name.replace(/\.(doc|docx)$/i,""),
      parentId:selectedPageId,
      parentTitle:selectedTitle||selectedPageId,
      createFolder,
      folderTitle,
      status:"pending",
      pageUrl:"",
      pageId:""
    });
    n++;
  }
  $("batchFiles").value="";
  $("batchResult").textContent=`已加入 ${n} 个文件。`;
  renderBatchList();
}

function renderBatchList(){
  const el=$("batchList");el.innerHTML="";
  if(!batchItems.length){
    const d=document.createElement("div");d.className="hint";d.style.padding="10px";d.textContent="批量队列为空。";el.appendChild(d);return;
  }
  const groups=new Map();
  batchItems.forEach((it,i)=>{
    const target=it.createFolder?`${it.parentTitle} / ${it.folderTitle}`:it.parentTitle;
    const key=`${it.parentId}::${it.createFolder?it.folderTitle:""}`;
    if(!groups.has(key))groups.set(key,{target,parentTitle:it.parentTitle,folderTitle:it.folderTitle,createFolder:it.createFolder,items:[]});
    groups.get(key).items.push({it,i});
  });
  for(const g of groups.values()){
    const ge=document.createElement("div");ge.className="batch-group";
    const h=document.createElement("div");h.className="batch-group-head";
    h.innerHTML=`<div class="batch-group-title">目标：${esc(g.target)}</div><div class="batch-group-sub">${esc(g.createFolder?`父目录：${g.parentTitle} · 新建目录：${g.folderTitle}`:`父目录：${g.parentTitle}`)}</div>`;
    ge.appendChild(h);
    for(const {it,i} of g.items){
      const r=document.createElement("div");r.className="batch-row"+(it.pageUrl?" openable":"");
      if(it.pageUrl){
        r.title="点击打开已创建页面";
        r.onclick=e=>{if(e.target.classList.contains("batch-remove"))return;chrome.tabs.update({url:it.pageUrl});};
      }
      const left=document.createElement("div");
      left.innerHTML=`<div class="batch-title">${esc(it.pageTitle)}</div><div class="batch-meta">${esc(it.file.name)}</div>`;
      const st=document.createElement("div");
      st.className="batch-status "+(it.status==="success"?"success":it.status.startsWith("failed")?"failed":"");
      st.textContent=it.status==="success"?"success / 可打开":it.status;
      const rm=document.createElement("button");rm.className="batch-remove";rm.textContent="×";
      rm.onclick=e=>{e.stopPropagation();batchItems.splice(i,1);renderBatchList();};
      r.append(left,st,rm);ge.appendChild(r);
    }
    el.appendChild(ge);
  }
}

async function publishBatch(){
  if(!batchItems.length){$("batchResult").textContent="批量队列为空。";return;}
  $("batchResult").textContent="开始原生 Doc 导入...\n";
  let ok=0,fail=0;
  const folderCache=new Map();
  for(let i=0;i<batchItems.length;i++){
    const it=batchItems[i];it.status="publishing";renderBatchList();
    try{
      log(`\n[${i+1}/${batchItems.length}] 创建页面：${it.pageTitle}`);
      const result=await publishOneNative(it,folderCache);
      it.status="success";it.pageUrl=result.pageUrl;it.pageId=result.page.id;
      ok++;log(`成功：${result.pageUrl||result.page.id}`);
    }catch(e){
      it.status="failed: "+e.message;fail++;log("失败："+e.message);
    }
    renderBatchList();
  }
  log(`\n批量完成：成功 ${ok}，失败 ${fail}。成功项可点击打开页面。`);
}

async function publishOneNative(item,folderCache){
  const parentPage=await getPage(item.parentId);
  const spaceKey=parentPage.space&&parentPage.space.key;
  if(!spaceKey)throw Error("无法获取 space key");

  let parentId=item.parentId;
  if(item.createFolder){
    const key=`${item.parentId}::${item.folderTitle}`;
    if(folderCache.has(key)){
      parentId=folderCache.get(key).id;
    }else{
      const folder=await createRestPage(item.folderTitle,spaceKey,item.parentId,buildPublishHeaderStorage());
      folderCache.set(key,folder);
      parentId=folder.id;
    }
  }

  const blankPage=await createRestPage(item.pageTitle,spaceKey,parentId,"<p>Importing Word document...</p>");
  const pageId=blankPage.id;

  log(`上传 Word 到原生导入接口：${item.file.name}`);
  const token=await getAtlToken(pageId);
  await uploadWordToNativeImporter(pageId,item.file,token);

  log("执行 Confluence 原生导入...");
  await doNativeImport(pageId,item.pageTitle,token);

  log("补充发布时间 / 发布人...");
  await prependPublishHeader(pageId);

  const finalPage=await getPage(pageId);
  return {page:finalPage,pageUrl:pageUrl(finalPage)};
}

async function getAtlToken(pageId){
  const html=await getText(`/pages/worddav/uploadimport.action?pageId=${encodeURIComponent(pageId)}`);
  let m=html.match(/name=["']atl_token["'][^>]*value=["']([^"']+)["']/i);
  if(m)return decodeHtml(m[1]);
  m=html.match(/atl_token["']?\s*[:=]\s*["']([^"']+)["']/i);
  if(m)return decodeHtml(m[1]);
  throw Error("无法从 uploadimport.action 页面解析 atl_token");
}

async function uploadWordToNativeImporter(pageId,file,atlToken){
  const fd=new FormData();
  fd.append("atl_token",atlToken);
  fd.append("filename",file,file.name);
  fd.append("submit","下一步");

  const res=await fetch(`${BASE_URL}/pages/worddav/importword.action?pageId=${encodeURIComponent(pageId)}`,{
    method:"POST",
    credentials:"include",
    headers:{
      "Accept":"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
    },
    body:fd,
    redirect:"follow"
  });

  const text=await res.text();
  if(!res.ok)throw Error(`上传 Word 失败 HTTP ${res.status}: ${text.slice(0,500)}`);
  if(!text.includes("doimportword.action") && !text.includes("导入Word文档") && !text.includes("Import Word")){
    console.warn("Upload response does not look like import config page", text.slice(0,500));
  }
  return text;
}

async function doNativeImport(pageId,pageTitle,atlToken){
  const params=new URLSearchParams();
  params.set("atl_token",atlToken);
  params.set("pageId",String(pageId));
  params.set("treeDepth",treeDepth || "0");
  params.set("advanced","true");
  params.set("docTitle",pageTitle);
  params.set("importSpace","false");
  params.set("conflict","1");
  params.set("submit","导入");

  const res=await fetch(`${BASE_URL}/pages/worddav/doimportword.action`,{
    method:"POST",
    credentials:"include",
    headers:{
      "Accept":"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
      "Content-Type":"application/x-www-form-urlencoded"
    },
    body:params.toString(),
    redirect:"follow"
  });

  const text=await res.text();
  if(!res.ok)throw Error(`原生导入失败 HTTP ${res.status}: ${text.slice(0,500)}`);
  return text;
}

async function prependPublishHeader(pageId){
  const page=await getJson(`/rest/api/content/${encodeURIComponent(pageId)}?expand=body.storage,version,space,_links`);
  const current=page.body&&page.body.storage&&page.body.storage.value ? page.body.storage.value : "";
  const header=buildPublishHeaderStorage();
  const value=header+"\n"+current;

  const body={
    id:String(page.id),
    type:"page",
    title:page.title,
    version:{number:(page.version.number||1)+1},
    body:{storage:{value,representation:"storage"}}
  };

  await putJson(`/rest/api/content/${encodeURIComponent(page.id)}`,body);
}

function buildPublishHeaderStorage(){
  const d=new Date();
  const date=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
  return `<p><strong>发布时间：</strong><time datetime="${date}" /></p><p><strong>发布人：${escapeXml(userName())}</strong></p><hr />`;
}

async function getJson(path){
  const r=await fetch(BASE_URL+path,{credentials:"include",headers:{Accept:"application/json"}});
  const t=await r.text();
  if(!r.ok)throw Error(`HTTP ${r.status}: ${t.slice(0,500)}`);
  return t?JSON.parse(t):null;
}

async function getText(path){
  const r=await fetch(BASE_URL+path,{credentials:"include",headers:{Accept:"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"}});
  const t=await r.text();
  if(!r.ok)throw Error(`HTTP ${r.status}: ${t.slice(0,500)}`);
  return t;
}

async function postJson(path,body){
  const r=await fetch(BASE_URL+path,{
    method:"POST",
    credentials:"include",
    headers:{Accept:"application/json","Content-Type":"application/json","X-Atlassian-Token":"nocheck"},
    body:JSON.stringify(body)
  });
  const t=await r.text();
  if(!r.ok)throw Error(`HTTP ${r.status}: ${t.slice(0,800)}`);
  return t?JSON.parse(t):null;
}

async function putJson(path,body){
  const r=await fetch(BASE_URL+path,{
    method:"PUT",
    credentials:"include",
    headers:{Accept:"application/json","Content-Type":"application/json","X-Atlassian-Token":"nocheck"},
    body:JSON.stringify(body)
  });
  const t=await r.text();
  if(!r.ok)throw Error(`HTTP ${r.status}: ${t.slice(0,800)}`);
  return t?JSON.parse(t):null;
}

async function getPage(id){
  return getJson(`/rest/api/content/${encodeURIComponent(id)}?expand=space,_links`);
}

async function getChildren(id){
  const d=await getJson(`/rest/api/content/${encodeURIComponent(id)}/child/page?limit=100&expand=space,_links`);
  return d.results||[];
}

async function createRestPage(title,spaceKey,parentId,storageValue){
  return postJson("/rest/api/content",{
    type:"page",
    title,
    space:{key:spaceKey},
    ancestors:[{id:String(parentId)}],
    body:{storage:{value:storageValue,representation:"storage"}}
  });
}

function pageUrl(p){
  return p&&p._links&&p._links.webui ? BASE_URL+p._links.webui : (p&&p.id ? `${BASE_URL}/pages/viewpage.action?pageId=${p.id}` : "");
}

function setTreeStatus(t,e=false){$("treeStatus").textContent=t;$("treeStatus").className=e?"status err":"status";}
function log(s){$("batchResult").textContent+=s+"\n";$("batchResult").scrollTop=$("batchResult").scrollHeight;}

function esc(s){return String(s??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");}
function escapeXml(s){return esc(s);}
function decodeHtml(s){
  const t=document.createElement("textarea");
  t.innerHTML=s;
  return t.value;
}
