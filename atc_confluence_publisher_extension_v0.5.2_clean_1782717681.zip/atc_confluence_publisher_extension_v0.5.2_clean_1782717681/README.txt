ATC Confluence Publisher Extension v0.5.2

功能：
- 选择 Confluence 目标目录
- 可选新建目录
- 批量导入 Word
- 使用 Confluence 原生 Doc 导入链路
- 自动添加发布时间和发布人

安装：
1. 解压 zip
2. 打开 chrome://extensions 或 edge://extensions
3. 开启开发者模式
4. 加载已解压的扩展
5. 打开 Confluence 后点击扩展图标
