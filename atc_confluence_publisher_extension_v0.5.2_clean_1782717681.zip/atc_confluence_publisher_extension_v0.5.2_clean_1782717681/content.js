console.log("[ATC Publisher] loaded", location.href);
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "GET_PAGE_INFO") {
    sendResponse({ url: location.href, title: document.title });
  }
  return true;
});
