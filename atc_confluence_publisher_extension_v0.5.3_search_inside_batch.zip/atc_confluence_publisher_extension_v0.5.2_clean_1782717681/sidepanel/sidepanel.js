const BASE_URL="https://atc.bmw-brilliance.cn/confluence";
const $=id=>document.getElementById(id);
let rootPageId="",selectedPageId=null,selectedTitle=null,currentUser=null,batchItems=[],treeDepth="0";
let directoryIndex=[],directoryIndexLoaded=false,directoryIndexLoading=false,searchTimer=null;
const INTERNAL_FOLDER_DELAY_MS=300;

init();

async function init(){
  bind();
  const saved=await chrome.storage.local.get(["rootPageId","selectedPageId","selectedTitle","treeDepth"]);
  rootPageId=saved.rootPageId||"";
  treeDepth=saved.treeDepth||"0";
  $("settingsRootPageId").value=rootPageId;
  $("settingsTreeDepth").value=treeDepth;
  if(rootPageId)$("rootStatusLabel").textContent=`Root：${rootPageId}`;

  if(saved.selectedPageId){
    selectedPageId=saved.selectedPageId;
    selectedTitle=saved.selectedTitle||"";
    refreshSelected();
  }

  renderBatchList();
  await loadUser();

  if(rootPageId){
    await loadTree();
    await validateSavedSelection();
  }else{
    setTreeStatus("请先配置 Root Page ID。");
  }
}

function bind(){
  $("reloadTreeBtn").onclick=async()=>{directoryIndexLoaded=false;directoryIndex=[];clearSearchResults();await loadTree();};
  $("openSettingsBtn").onclick=()=>$("settingsModal").classList.remove("hidden");
  $("closeSettingsBtn").onclick=()=>$("settingsModal").classList.add("hidden");
  $("saveSettingsBtn").onclick=()=>saveSettings(false);
  $("settingsReloadTreeBtn").onclick=()=>saveSettings(true);
  $("openTargetSelectorBtn").onclick=openTargetSelector;
  $("batchChooseTargetBtn").onclick=openTargetSelector;
  $("closeTargetSelectorBtn").onclick=()=>$("targetSelectorModal").classList.add("hidden");
  $("reloadTargetSelectorBtn").onclick=loadTargetSelectorTree;
  $("addBatchBtn").onclick=addBatch;
  $("clearBatchBtn").onclick=()=>{batchItems=[];renderBatchList();$("batchResult").textContent="队列已清空。"};
  $("publishBatchBtn").onclick=publishBatch;
  $("directorySearchInput").addEventListener("input",onDirectorySearchInput);
  $("directorySearchInput").addEventListener("focus",onDirectorySearchInput);
}

async function saveSettings(reload){
  rootPageId=$("settingsRootPageId").value.trim();
  treeDepth=$("settingsTreeDepth").value;
  directoryIndexLoaded=false;
  directoryIndex=[];
  clearSearchResults();
  if(!rootPageId){$("settingsResult").textContent="Root Page ID 不能为空。";return;}
  await chrome.storage.local.set({rootPageId,treeDepth});
  $("rootStatusLabel").textContent=`Root：${rootPageId}`;
  $("settingsResult").textContent="设置已保存。";
  if(reload){$("settingsModal").classList.add("hidden");await loadTree();}
}

async function loadUser(){
  try{
    currentUser=await getJson("/rest/api/user/current");
    $("currentUserLabel").textContent=`用户：${userName()}`;
  }catch(e){
    $("currentUserLabel").textContent="用户：读取失败";
  }
}

function userName(){
  return currentUser?.displayName||currentUser?.fullName||currentUser?.username||currentUser?.name||"Unknown";
}

async function loadTree(){
  if(!rootPageId){setTreeStatus("请先配置 Root Page ID。",true);return;}
  $("pageTree").innerHTML="";
  setTreeStatus("正在加载目录树...");
  try{
    const p=await getPage(rootPageId);
    $("pageTree").appendChild(treeNode(p,{}));
    setTreeStatus("目录树已加载。");
  }catch(e){
    if(isNotFound(e)){
      setTreeStatus("Root Page ID 无效或已删除，请重新设置。",true);
    }else{
      setTreeStatus("加载失败："+shortErr(e),true);
    }
  }
}

async function validateSavedSelection(){
  if(!selectedPageId)return;
  try{
    await getPage(selectedPageId);
  }catch(e){
    if(isNotFound(e)){
      selectedPageId=null;
      selectedTitle=null;
      await chrome.storage.local.remove(["selectedPageId","selectedTitle"]);
      refreshSelected();
      $("batchResult").textContent="已清空失效的目标目录，请重新选择。";
    }
  }
}

async function openTargetSelector(){
  $("targetSelectorModal").classList.remove("hidden");
  await loadTargetSelectorTree();
}

async function loadTargetSelectorTree(){
  $("targetSelectorTree").innerHTML="";
  if(!rootPageId){
    $("targetSelectorStatus").textContent="请先配置 Root Page ID。";
    $("targetSelectorStatus").className="status err";
    return;
  }
  $("targetSelectorStatus").textContent="正在加载...";
  $("targetSelectorStatus").className="status";
  try{
    const p=await getPage(rootPageId);
    $("targetSelectorTree").appendChild(treeNode(p,{modal:true}));
    $("targetSelectorStatus").textContent="点击目录标题即可选择。";
  }catch(e){
    $("targetSelectorStatus").textContent=isNotFound(e)?"Root Page ID 无效或已删除。":"加载失败："+shortErr(e);
    $("targetSelectorStatus").className="status err";
  }
}

function treeNode(page,opt={}){
  const w=document.createElement("div");w.className="tree-node";w.dataset.loaded="false";w.dataset.expanded="false";
  const r=document.createElement("div");r.className="tree-row";
  const b=document.createElement("button");b.className="expand-btn";b.textContent="▶";b.type="button";
  const t=document.createElement("span");t.className="page-title";t.textContent=page.title;t.title=page.title;
  const c=document.createElement("div");c.className="children";c.style.display="none";
  b.onclick=async e=>{e.stopPropagation();await toggle(w,b,c,page.id,opt);};
  r.onclick=()=>selectNode(r,page.id,page.title,opt);
  r.append(b,t);w.append(r,c);return w;
}

async function toggle(w,b,c,id,opt){
  const ex=w.dataset.expanded==="true",lo=w.dataset.loaded==="true";
  if(ex){w.dataset.expanded="false";b.textContent="▶";c.style.display="none";return;}
  w.dataset.expanded="true";b.textContent="▼";c.style.display="block";
  if(!lo){
    c.textContent="加载中...";
    try{
      const ch=await getChildren(id);
      c.innerHTML="";
      if(!ch.length)c.textContent="没有子页面";
      else ch.forEach(x=>c.appendChild(treeNode(x,opt)));
      w.dataset.loaded="true";
    }catch(e){
      c.textContent=isNotFound(e)?"页面不存在或已删除":"加载失败："+shortErr(e);
    }
  }
}

function selectNode(row,id,title,opt={}){
  document.querySelectorAll(".tree-row.selected").forEach(x=>x.classList.remove("selected"));
  row.classList.add("selected");
  setSelectedTarget(id,title);
  if(opt.modal)$("targetSelectorModal").classList.add("hidden");
}

function setSelectedTarget(id,title){
  selectedPageId=id;
  selectedTitle=title;
  refreshSelected();
  chrome.storage.local.set({selectedPageId,selectedTitle});
}

function refreshSelected(){
  $("selectedTitle").textContent=selectedTitle||"未选择";
  $("selectedPageId").textContent=selectedPageId||"-";
  $("batchSelectedTitle").textContent=selectedTitle||"未选择";
  $("batchSelectedPageId").textContent=selectedPageId||"-";
}


async function onDirectorySearchInput(){
  clearTimeout(searchTimer);
  const q=$("directorySearchInput").value.trim();
  searchTimer=setTimeout(async()=>{await runDirectorySearch(q);},180);
}

async function runDirectorySearch(q){
  if(!q){
    clearSearchResults();
    $("directorySearchStatus").textContent="";
    return;
  }
  if(!rootPageId){
    showSearchEmpty("请先配置 Root Page ID。");
    return;
  }
  try{
    await ensureDirectoryIndex();
    const nq=q.toLowerCase();
    const starts=directoryIndex.filter(x=>x.title.toLowerCase().startsWith(nq));
    const contains=directoryIndex.filter(x=>!x.title.toLowerCase().startsWith(nq) && x.title.toLowerCase().includes(nq));
    const results=[...starts,...contains].slice(0,80);
    if(!results.length){
      showSearchEmpty("无此目录");
      $("directorySearchStatus").textContent="";
      return;
    }
    renderSearchResults(results);
    $("directorySearchStatus").textContent=`找到 ${results.length} 个匹配目录`;
    $("directorySearchStatus").className="status ok";
  }catch(e){
    showSearchEmpty("搜索失败："+shortErr(e));
  }
}

async function ensureDirectoryIndex(){
  if(directoryIndexLoaded)return;
  if(directoryIndexLoading){
    while(directoryIndexLoading)await sleep(100);
    return;
  }
  directoryIndexLoading=true;
  $("directorySearchStatus").textContent="正在加载目录索引...";
  $("directorySearchStatus").className="status";
  try{
    directoryIndex=[];
    const root=await getPage(rootPageId);
    await collectDescendants(root.id, root.title, 0);
    directoryIndexLoaded=true;
  }finally{
    directoryIndexLoading=false;
  }
}

async function collectDescendants(parentId,parentPath,depth){
  const children=await getAllChildren(parentId);
  for(const child of children){
    const path=parentPath ? `${parentPath} / ${child.title}` : child.title;
    directoryIndex.push({id:child.id,title:child.title,path});
    if(depth<20){
      await collectDescendants(child.id,path,depth+1);
    }
  }
}

async function getAllChildren(id){
  let start=0;
  const all=[];
  while(true){
    const d=await getJson(`/rest/api/content/${encodeURIComponent(id)}/child/page?limit=100&start=${start}&expand=space,_links`);
    const results=d.results||[];
    all.push(...results);
    if(!d._links || !d._links.next || !results.length)break;
    start+=results.length;
  }
  return all;
}

function renderSearchResults(results){
  const box=$("directorySearchResults");
  box.innerHTML="";
  box.classList.add("show");
  for(const item of results){
    const div=document.createElement("div");
    div.className="search-item";
    div.innerHTML=`<div class="search-title">${esc(item.title)}</div><div class="search-path">${esc(item.path)} · ${esc(item.id)}</div>`;
    div.onclick=()=>{
      setSelectedTarget(item.id,item.title);
      $("directorySearchInput").value=item.title;
      clearSearchResults();
      $("directorySearchStatus").textContent=`已选择：${item.title}`;
      $("directorySearchStatus").className="status ok";
    };
    box.appendChild(div);
  }
}

function showSearchEmpty(text){
  const box=$("directorySearchResults");
  box.innerHTML=`<div class="search-empty">${esc(text)}</div>`;
  box.classList.add("show");
  $("directorySearchStatus").className="status err";
}

function clearSearchResults(){
  const box=$("directorySearchResults");
  if(!box)return;
  box.innerHTML="";
  box.classList.remove("show");
}


function addBatch(){
  const files=Array.from($("batchFiles").files||[]);
  if(!selectedPageId){$("batchResult").textContent="请先选择目标目录。";return;}
  if(!files.length){$("batchResult").textContent="请先选择 Word 文件。";return;}
  const createFolder=$("batchCreateFolderCheckbox").checked;
  const folderTitle=$("batchFolderTitle").value.trim();
  if(createFolder&&!folderTitle){$("batchResult").textContent="请输入新目录名。";return;}
  let n=0;
  for(const file of files){
    if(!/\.(doc|docx)$/i.test(file.name))continue;
    batchItems.push({
      id:String(Date.now()+Math.random()),
      file,
      pageTitle:file.name.replace(/\.(doc|docx)$/i,""),
      parentId:selectedPageId,
      parentTitle:selectedTitle||selectedPageId,
      createFolder,
      folderTitle,
      status:"pending",
      pageUrl:"",
      pageId:"",
      tempTitle:""
    });
    n++;
  }
  $("batchFiles").value="";
  $("batchResult").textContent=`已加入 ${n} 个文件。`;
  renderBatchList();
}

function renderBatchList(){
  const el=$("batchList");el.innerHTML="";
  if(!batchItems.length){
    const d=document.createElement("div");d.className="hint";d.style.padding="10px";d.textContent="队列为空。";el.appendChild(d);return;
  }
  const groups=new Map();
  batchItems.forEach((it,i)=>{
    const target=it.createFolder?`${it.parentTitle} / ${it.folderTitle}`:it.parentTitle;
    const key=`${it.parentId}::${it.createFolder?it.folderTitle:""}`;
    if(!groups.has(key))groups.set(key,{target,parentTitle:it.parentTitle,folderTitle:it.folderTitle,createFolder:it.createFolder,items:[]});
    groups.get(key).items.push({it,i});
  });
  for(const g of groups.values()){
    const ge=document.createElement("div");ge.className="batch-group";
    const h=document.createElement("div");h.className="batch-group-head";
    h.innerHTML=`<div class="batch-group-title">目标：${esc(g.target)}</div><div class="batch-group-sub">${esc(g.createFolder?`父目录：${g.parentTitle} · 新目录：${g.folderTitle}`:`父目录：${g.parentTitle}`)}</div>`;
    ge.appendChild(h);
    for(const {it,i} of g.items){
      const r=document.createElement("div");r.className="batch-row"+(it.pageUrl?" openable":"");
      if(it.pageUrl){
        r.title="点击打开页面";
        r.onclick=e=>{if(e.target.classList.contains("batch-remove"))return;chrome.tabs.update({url:it.pageUrl});};
      }
      const left=document.createElement("div");
      left.innerHTML=`<div class="batch-title">${esc(it.pageTitle)}</div><div class="batch-meta">${esc(it.file.name)}</div>`;
      const st=document.createElement("div");
      st.className="batch-status "+(it.status==="success"?"success":it.status.startsWith("failed")?"failed":"");
      st.textContent=it.status==="success"?"success / 可打开":it.status;
      const rm=document.createElement("button");rm.className="batch-remove";rm.textContent="×";
      rm.onclick=e=>{e.stopPropagation();batchItems.splice(i,1);renderBatchList();};
      r.append(left,st,rm);ge.appendChild(r);
    }
    el.appendChild(ge);
  }
}

async function publishBatch(){
  if(!batchItems.length){$("batchResult").textContent="队列为空。";return;}
  $("batchResult").textContent="开始导入...\n";
  let ok=0,fail=0;
  const folderCache=new Map();
  for(let i=0;i<batchItems.length;i++){
    const it=batchItems[i];it.status="publishing";renderBatchList();
    try{
      log(`\n[${i+1}/${batchItems.length}] ${it.pageTitle}`);
      const result=await publishOneNative(it,folderCache);
      it.status="success";it.pageUrl=result.pageUrl;it.pageId=result.page.id;
      ok++;log(`完成：${result.pageUrl||result.page.id}`);
    }catch(e){
      it.status="failed: "+shortErr(e);fail++;log("失败："+shortErr(e));
    }
    renderBatchList();
  }
  log(`\n导入完成：成功 ${ok}，失败 ${fail}。`);
}

async function publishOneNative(item,folderCache){
  const parentPage=await getPage(item.parentId);
  const spaceKey=parentPage.space&&parentPage.space.key;
  if(!spaceKey)throw Error("无法获取 Space Key");

  let parentId=item.parentId;
  if(item.createFolder){
    const key=`${item.parentId}::${item.folderTitle}`;
    if(folderCache.has(key)){
      parentId=folderCache.get(key).id;
      log(`复用目录：${item.folderTitle}`);
    }else{
      log(`创建目录：${item.folderTitle}`);
      const folder=await createRestPage(item.folderTitle,spaceKey,item.parentId,buildPublishHeaderStorage());
      folderCache.set(key,folder);
      parentId=folder.id;
      await sleep(INTERNAL_FOLDER_DELAY_MS);
      await getPage(parentId);
    }
  }

  const tempTitle=makeTempImportTitle(item.pageTitle);
  item.tempTitle=tempTitle;
  renderBatchList();

  log("创建临时页...");
  const blankPage=await createRestPage(tempTitle,spaceKey,parentId,"<p>Importing Word document...</p>");
  const pageId=blankPage.id;

  log("获取令牌...");
  const token=await getAtlToken(pageId);

  log("上传 Word...");
  await uploadWordToNativeImporter(pageId,item.file,token);

  log("执行导入...");
  await doNativeImport(pageId,item.pageTitle,token);

  log("更新页面信息...");
  await prependPublishHeader(pageId);

  const finalPage=await getPage(pageId);
  return {page:finalPage,pageUrl:pageUrl(finalPage)};
}

function makeTempImportTitle(originalTitle){
  const now=new Date();
  const stamp=[
    now.getFullYear(),
    String(now.getMonth()+1).padStart(2,"0"),
    String(now.getDate()).padStart(2,"0"),
    String(now.getHours()).padStart(2,"0"),
    String(now.getMinutes()).padStart(2,"0"),
    String(now.getSeconds()).padStart(2,"0")
  ].join("");
  const rand=Math.random().toString(36).slice(2,7);
  const safe=String(originalTitle||"Word").replace(/[^\u4e00-\u9fa5a-zA-Z0-9_\- ]/g,"").slice(0,50);
  return `_DOC_IMPORT_TEMP_${stamp}_${rand}_${safe}`;
}

async function getAtlToken(pageId){
  const html=await getText(`/pages/worddav/uploadimport.action?pageId=${encodeURIComponent(pageId)}`);
  let m=html.match(/name=["']atl_token["'][^>]*value=["']([^"']+)["']/i);
  if(m)return decodeHtml(m[1]);
  m=html.match(/atl_token["']?\s*[:=]\s*["']([^"']+)["']/i);
  if(m)return decodeHtml(m[1]);
  throw Error("无法获取 atl_token");
}

async function uploadWordToNativeImporter(pageId,file,atlToken){
  const fd=new FormData();
  fd.append("atl_token",atlToken);
  fd.append("filename",file,file.name);
  fd.append("submit","下一步");

  const res=await fetch(`${BASE_URL}/pages/worddav/importword.action?pageId=${encodeURIComponent(pageId)}`,{
    method:"POST",
    credentials:"include",
    headers:{"Accept":"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"},
    body:fd,
    redirect:"follow"
  });

  const text=await res.text();
  if(!res.ok)throw Error(`上传 Word 失败 HTTP ${res.status}: ${text.slice(0,500)}`);
  return text;
}

async function doNativeImport(pageId,pageTitle,atlToken){
  const params=new URLSearchParams();
  params.set("atl_token",atlToken);
  params.set("pageId",String(pageId));
  params.set("treeDepth",treeDepth || "0");
  params.set("advanced","true");
  params.set("docTitle",pageTitle);
  params.set("importSpace","false");
  params.set("conflict","1");
  params.set("submit","导入");

  const res=await fetch(`${BASE_URL}/pages/worddav/doimportword.action`,{
    method:"POST",
    credentials:"include",
    headers:{
      "Accept":"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
      "Content-Type":"application/x-www-form-urlencoded"
    },
    body:params.toString(),
    redirect:"follow"
  });

  const text=await res.text();
  if(!res.ok)throw Error(`导入失败 HTTP ${res.status}: ${text.slice(0,500)}`);
  return text;
}

async function prependPublishHeader(pageId){
  const page=await getJson(`/rest/api/content/${encodeURIComponent(pageId)}?expand=body.storage,version,space,_links`);
  const current=page.body&&page.body.storage&&page.body.storage.value ? page.body.storage.value : "";
  const header=buildPublishHeaderStorage();

  if(current.includes("发布时间：") && current.includes("发布人："))return;

  const body={
    id:String(page.id),
    type:"page",
    title:page.title,
    version:{number:(page.version.number||1)+1},
    body:{storage:{value:header+"\n"+current,representation:"storage"}}
  };

  await putJson(`/rest/api/content/${encodeURIComponent(page.id)}`,body);
}

function buildPublishHeaderStorage(){
  const d=new Date();
  const date=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
  return `<p><strong>发布时间：</strong><time datetime="${date}" /></p><p><strong>发布人：${escapeXml(userName())}</strong></p><hr />`;
}

async function getJson(path){
  const r=await fetch(BASE_URL+path,{credentials:"include",headers:{Accept:"application/json"}});
  const t=await r.text();
  if(!r.ok)throw Error(`HTTP ${r.status}: ${t.slice(0,500)}`);
  return t?JSON.parse(t):null;
}

async function getText(path){
  const r=await fetch(BASE_URL+path,{credentials:"include",headers:{Accept:"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"}});
  const t=await r.text();
  if(!r.ok)throw Error(`HTTP ${r.status}: ${t.slice(0,500)}`);
  return t;
}

async function postJson(path,body){
  const r=await fetch(BASE_URL+path,{
    method:"POST",
    credentials:"include",
    headers:{Accept:"application/json","Content-Type":"application/json","X-Atlassian-Token":"nocheck"},
    body:JSON.stringify(body)
  });
  const t=await r.text();
  if(!r.ok)throw Error(`HTTP ${r.status}: ${t.slice(0,800)}`);
  return t?JSON.parse(t):null;
}

async function putJson(path,body){
  const r=await fetch(BASE_URL+path,{
    method:"PUT",
    credentials:"include",
    headers:{Accept:"application/json","Content-Type":"application/json","X-Atlassian-Token":"nocheck"},
    body:JSON.stringify(body)
  });
  const t=await r.text();
  if(!r.ok)throw Error(`HTTP ${r.status}: ${t.slice(0,800)}`);
  return t?JSON.parse(t):null;
}

async function getPage(id){
  return getJson(`/rest/api/content/${encodeURIComponent(id)}?expand=space,_links`);
}

async function getChildren(id){
  const d=await getJson(`/rest/api/content/${encodeURIComponent(id)}/child/page?limit=100&expand=space,_links`);
  return d.results||[];
}

async function createRestPage(title,spaceKey,parentId,storageValue){
  return postJson("/rest/api/content",{
    type:"page",
    title,
    space:{key:spaceKey},
    ancestors:[{id:String(parentId)}],
    body:{storage:{value:storageValue,representation:"storage"}}
  });
}

function pageUrl(p){
  return p&&p._links&&p._links.webui ? BASE_URL+p._links.webui : (p&&p.id ? `${BASE_URL}/pages/viewpage.action?pageId=${p.id}` : "");
}

function sleep(ms){return new Promise(resolve=>setTimeout(resolve,ms));}
function setTreeStatus(t,e=false){$("treeStatus").textContent=t;$("treeStatus").className=e?"status err":"status";}
function log(s){$("batchResult").textContent+=s+"\n";$("batchResult").scrollTop=$("batchResult").scrollHeight;}
function shortErr(e){return String(e&&e.message?e.message:e).replace(/\s+/g," ").slice(0,260);}
function isNotFound(e){return String(e&&e.message?e.message:e).includes("HTTP 404");}
function esc(s){return String(s??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");}
function escapeXml(s){return esc(s);}
function decodeHtml(s){
  const t=document.createElement("textarea");
  t.innerHTML=s;
  return t.value;
}
